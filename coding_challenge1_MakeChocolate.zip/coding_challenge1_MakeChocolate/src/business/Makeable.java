package business;

public interface Makeable {
	// list of all standardized interface methods
	
	void resetBarCount();
	void getBarCount();
}
